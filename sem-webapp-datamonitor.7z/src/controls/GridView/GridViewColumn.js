import ToolTips from '../ToolTips'
import { dateFormat } from '../../helper'

const GridViewColumn = ({ row, col, index, rowStyle }) => {
    return (
        <td key={`${index}-${row[col.field]}`} className={col.css + ' ' + rowStyle}>
            <ToolTips
                value={
                    col?.dataType === 'DateTime' ? dateFormat(row[col.field]) : row[col.field]
                }
                trimLength={col?.trunacteSize > 0 ? col?.trunacteSize : 20}
            />
        </td >
    )
}
export default GridViewColumn