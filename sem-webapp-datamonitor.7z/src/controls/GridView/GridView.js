import './GridView.css';
import EmptyTemplate from '../../components/EmptyTemplate'
import GridViewRow from './GridViewRow'

const GridView = ({ heading, schema, data, isSerialCol }) => {

    return (
        <>
            {
                heading?.length > 0 ?
                    <div id='grid-header' className='mt-1' >
                        <h4 className="d-flex justify-content-start">{heading}</h4>
                        <span className="d-flex justify-content-end">Total Records: {data.length}</span>
                    </div>
                    : ''
            }
            <div id='grid-container' className='overflow-auto'>

                <table className="table grid-view">
                    <thead>

                        {data.length > 0 ? <tr >
                            {isSerialCol === true ? <th className='col-1'>Serial#</th> : ''}
                            {
                                schema?.columns?.map((obj, index) => {
                                    return <th className={obj.css} key={index} scope="col">{obj.label}</th>
                                })
                            }
                        </tr>
                            : ''
                        }
                    </thead>
                    <tbody>
                        {
                            data.length > 0 ?
                                data?.map((row, rowIndex) => {
                                    let rowStyle = ''

                                    schema?.rules?.map(rule => {
                                        if (row[rule?.field]?.toString().toLowerCase() === rule?.value?.toString().toLowerCase()) {
                                            rowStyle = rule?.cssStyle
                                            return rowStyle
                                        }
                                    })
                                    return <GridViewRow schema={schema} row={row} rowIndex={rowIndex} rowStyle={rowStyle} isSerialCol={isSerialCol} />
                                })
                                : < EmptyTemplate />
                        }
                    </tbody>
                </table>
            </div >
        </>
    )
}

export default GridView