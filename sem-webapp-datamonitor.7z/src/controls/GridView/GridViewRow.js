import GridViewColumn from './GridViewColumn'


const GridViewRow = ({ schema, row, rowIndex, isSerialCol, rowStyle }) => {

    return (

        <tr key={rowIndex} >
            {isSerialCol === true ? <td key={'td' + rowIndex} className='col-1'>{rowIndex + 1}</td> : ''}
            {
                schema?.columns?.map((col, colIndex) => {

                    return col.type === 'ReadOnly' ? <GridViewColumn row={row} col={col} index={colIndex} rowStyle={rowStyle} />

                        : <td test='template' className={col.css}>
                            {
                                col.template(rowIndex, row)
                            }
                        </td>
                })
            }
        </tr>)
}
export default GridViewRow