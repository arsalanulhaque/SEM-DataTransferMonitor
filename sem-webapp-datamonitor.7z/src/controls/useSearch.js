import React, { useState, useEffect, useContext } from 'react';


const useSearch = (keyword) => {
    const [searchField, setSearchField] = useState(keyword);

    const handleChange = e => {
        setSearchField(keyword);
    };

    return (searchField)
}

export default useSearch;