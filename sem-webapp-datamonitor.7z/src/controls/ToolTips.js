import OverlayTrigger from "react-bootstrap/OverlayTrigger";
import Tooltip from "react-bootstrap/Tooltip";

const ToolTips = ({ css, value, trimLength }) => {
    const renderTooltip = props => (
        <Tooltip  {...props} > {value} </Tooltip>
    )
    return (
        <>
            {
                value?.toString().length <= 0 ? <p className="p-1"></p> :
                    value?.toString().length < trimLength ? <span className={css}>{value}</span >
                        :
                        <OverlayTrigger placement="auto" overlay={renderTooltip} delay={{ show: 250, hide: 250 }}>
                            <div>
                                {value?.toString().length < trimLength ? value : value?.toString().slice(0, trimLength)}
                                <span id="more" className="text-muted"> . . .</span>
                            </div>
                        </OverlayTrigger>
            }
        </>
    )
}

export default ToolTips