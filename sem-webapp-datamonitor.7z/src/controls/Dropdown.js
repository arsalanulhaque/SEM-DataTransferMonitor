import { MultiSelect } from "react-multi-select-component";

function Dropdown({ id, label, list, selectedValue, onValueChange, style, enableSelectAll, closeonChange }) {

    return (
        <>
            <label htmlFor={id}>{label}</label>
            <MultiSelect id={id} className={style} hasSelectAll={enableSelectAll} closeOnChangedValue={closeonChange}
                options={list}
                value={selectedValue}
                onChange={(e) => {
                    onValueChange(id, e)
                }}
                labelledBy="Select"
            />
        </>
    )
}

export default Dropdown;