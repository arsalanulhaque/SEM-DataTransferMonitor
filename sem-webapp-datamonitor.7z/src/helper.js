export const setDate = (date, daysAddorSub, convertToDate) => {
    date = new Date(date)
    if (daysAddorSub !== 0) date.setDate(date.getDate() + daysAddorSub)
    return convertToDate ? (date.toISOString().slice(0, 10)) : date
}

export const dateFormat = (date) => {
    const today = new Date(date);
    const yyyy = today.getFullYear();
    let mm = today.getMonth() + 1; // Months start at 0!
    let dd = today.getDate();
    let hr = today.getHours()
    let min = today.getMinutes()
    let sec = today.getSeconds()

    if (dd < 10) dd = '0' + dd
    if (mm < 10) mm = '0' + mm
    if (hr < 10) hr = '0' + hr
    if (min < 10) min = '0' + min
    if (sec < 10) sec = '0' + sec

    const formattedToday = dd + '/' + mm + '/' + yyyy + ' ' + hr + ':' + min + ':' + sec;
    return formattedToday
}

export const getByKey = (data, key) => {
    let temp = [];
    data.forEach((element) => {
        temp.push(element[key]);
    });
    return temp;
}

export const getJsonObjsArrayByKey = (data, key) => {
    let temp = [];
    data.forEach((element) => {
        temp.push(element[key]);
    });
    return removeDuplicates(temp)
}

export const filterArrayObjByKey = (key, value, arrayOfObjects, useLikeOperator = false) => {
    if (value !== null) {
        if (!useLikeOperator) {
            return arrayOfObjects.filter(row => row[key].toString() === value.toString())
        }
        else {
            return arrayOfObjects.filter(row => row[key].toString().includes(value))
        }
    }
}

export const sortArrayObjByDate = (records, sortBy, asc) => {
    records.sort((a, b) => {
        return asc === true ? new Date(a[sortBy]) - new Date(b[sortBy]) : new Date(b[sortBy]) - new Date(a[sortBy])
    })
}

//Comparer Function    
export const sortArrayObjByKey = (prop) => {
    return (a, b) => {
        if (a[prop] > b[prop]) {
            return 1;
        } else if (a[prop] < b[prop]) {
            return -1;
        }
        return 0;
    }
}

export const removeDuplicates = (list) => {
    var uniquearr = [];

    if (list.filter(o => o === ' ' || o === '')?.length > 0) {
        uniquearr.push(' ')
        list = list.filter(o => o !== ' ')
    }

    list.forEach(x => {
        let val = x.toString().replace(new RegExp(' ', 'g'), '')
        if (!uniquearr.find(y => y.toString().replace(new RegExp(' ', 'g'), '') === val)) {
            uniquearr.push(val)
        }
    })
    return uniquearr
}