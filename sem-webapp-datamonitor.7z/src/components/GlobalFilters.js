import React, { useState, useContext, useEffect } from 'react'
import { setDate } from '../helper'
import { SocketContext } from '../context/Socket';
import { SessionContext } from "../context/Session"


function GlobalFilters() {
    const socket = useContext(SocketContext)
    const { session, setClientSession } = useContext(SessionContext)

    const onGlobalFilterChanged = (args) => {
        let startDate = Date.now()
        let endDate = setDate(Date.now(), 0, false)
        switch (args) {
            case 'today':
                startDate = setDate(startDate, 0, false)
                endDate = setDate(Date.now(), 0, false)
                setClientSession({ ...session, startDate: startDate, endDate: endDate, filterName: args })
                break;
            case '7days':
                startDate = setDate(startDate, -7, false)
                setClientSession({ ...session, startDate: startDate, endDate: endDate, filterName: args })
                break;
            case '30days':
                startDate = setDate(startDate, -30, false)
                setClientSession({ ...session, startDate: startDate, endDate: endDate, filterName: args })
                break;
        }
    }

    useEffect(() => {
        //Notify server about the changes
        if (session !== undefined) {
            socket.emit('updateDTMSession', session)
        }
    }, [session])


    return (
        <div className="d-grid gap-2 d-md-flex justify-content-md-center mt-1">
            <button className={session?.filterName === 'today' ? "btn btn-sm btn-primary me-md-4" : "btn btn-sm btn-outline-primary me-md-4"}
                type="button" onClick={() => {
                    onGlobalFilterChanged('today')
                }}>Today</button>

            <button className={session?.filterName === '7days' ? "btn btn-sm btn-primary me-md-4" : "btn btn-sm btn-outline-primary me-md-4"}
                type="button" onClick={() => {
                    onGlobalFilterChanged('7days')
                }}>7 Days</button>

            <button className={session?.filterName === '30days' ? "btn btn-sm btn-primary me-md-4" : "btn btn-sm btn-outline-primary me-md-4"}
                type="button" onClick={() => {
                    onGlobalFilterChanged('30days')
                }}>30 Days</button>
        </div>
    )
}

export default GlobalFilters