import { useState } from 'react';
import SessionInstance from "../context/Session"

const Footer = () => {
    const [filters, setFilters] = useState(SessionInstance.getSession())

    return (
        <footer >
            {filters.sessionID}
            <br />
            {filters.socketID}
            <br />
            ©SEM 2022
        </footer>
    )
}

export default Footer;