import { Link, } from 'react-router-dom';
import ErrorDialog from './ErrorDialog'
import Footer from './Footer'
import Clock from './Clock';
import AutoNavigateLink from './AutoNavigateLink';

const Header = ({ title }) => {

    return (
        <>
            <header className='header'>
                <div className="row">
                    <div className="col">

                        {/* Auto Navigation Button */}
                        <AutoNavigateLink />
                        <Link to={`/`} className={(window.location.pathname.toLowerCase().replace('datatransfermonitor', '')).replace('//', '/') === '/' ? 'nav-item-active' : 'nav-item'}>Main Dashboard</Link>
                        <span className='separator'></span>

                        <Link to={`/masterdatatransfer`} className={window.location.pathname.toLowerCase().includes('masterdatatransfer') === true ? 'nav-item-active' : 'nav-item'}>S/No or Master Data</Link>
                        <span className='separator'></span>

                        <Link to={`/report`} className={window.location.pathname.toLowerCase().includes('report') === true ? 'nav-item-active' : 'nav-item'}>Report</Link>
                    </div>

                    <div className="col">
                        < h1 className="text-center " > {title}</h1 >
                    </div>
                    <div className="col">
                        <Clock />
                    </div>
                </div>
                <ErrorDialog />
            </header >
            <Footer />
        </>)
}

export default Header;