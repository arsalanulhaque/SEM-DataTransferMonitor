import React, { useState, useEffect, useContext, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { SocketContext } from '../context/Socket';
import ErrorDialog from './ErrorDialog'
import Footer from './Footer'
import { SessionContext } from "../context/Session"

const Header = (props) => {
    const socket = useContext(SocketContext);
    const { session, setClientSession } = useContext(SessionContext)
    const [clock, setClock] = useState("");
    const [title, setTitle] = useState("");
    const navigate = useNavigate();


    useEffect(() => {
        const intervalId = setInterval(() => {
            if (session.autoNavigation.enabled === true) {
                let currentUrl = window.location.pathname
                currentUrl = currentUrl.replace('DataTransferMonitor', '').replace('//', '/')

                session.autoNavigation.urls.map((link, index) => {
                    console.log('currentUrl', currentUrl, `link${index}: `, link)
                    if (link.toLowerCase() === currentUrl.toLowerCase()) {
                        console.log(session.autoNavigation.urls[index === session.autoNavigation.urls.length - 1 ? 0 : index + 1])
                        navigate(session.autoNavigation.urls[index === session.autoNavigation.urls.length - 1 ? 0 : index + 1])
                    }
                })
            }

            if (session.autoNavigation.enabled === false) {
                clearInterval(intervalId);
            }
        }, 60000)

        // CLEAN UP THE EFFECT
        return () => {
            clearInterval(intervalId);
        }
    }, [setClientSession, session.autoNavigation.enabled]);

    useEffect(() => {
        setTitle(props.title)
        console.log('socket: ', socket.id)
    }, [props.title, setTitle, socket.id]);

    useEffect(() => {
        const timerEvent = (time) => { setClock(time) }
        socket.on('timerEvent', timerEvent);
        // CLEAN UP THE EFFECT
        return () => {
            socket.off('timerEvent', timerEvent)
        }
    }, [socket, setClock]);

    return (
        <>
            <header className='header'>
                <div className="row">
                    <div className="col">

                        <img className={session.autoNavigation.enabled === true ? 'reloadButton rotate' : 'reloadButton'}
                            onClick={() => { session.autoNavigation.enabled = !session.autoNavigation.enabled }}
                            src={`${process.env.PUBLIC_URL}/reload.png`} alt='Auto Navigation' title={session.autoNavigation.enabled === true ? 'Click to stop Auto Page Navigation' : 'Click to start Auto Page Navigation'} />
                        <span className='separator'></span>

                        <Link to={`/`} className={(window.location.pathname.toLowerCase().replace('datatransfermonitor', '')).replace('//', '/') === '/' ? 'nav-item-active' : 'nav-item'}>Main Dashboard</Link>
                        <span className='separator'></span>

                        <Link to={`/masterdatatransfer`} className={window.location.pathname.toLowerCase().includes('masterdatatransfer') === true ? 'nav-item-active' : 'nav-item'}>S/No or Master Data</Link>
                        <span className='separator'></span>

                        <Link to={`/report`} className={window.location.pathname.toLowerCase().includes('report') === true ? 'nav-item-active' : 'nav-item'}>Report</Link>
                    </div>

                    <div className="col">
                        < h1 className="text-center " > {title}</h1 >
                    </div>
                    <div className="col">
                        <span id='clock'>{clock}</span>
                    </div>
                </div>
                <ErrorDialog />
            </header >
            <Footer />
        </>)
}

export default Header;