import React, { useState, } from 'react';
import objInterval from '../hooks/useInterval'
import { useNavigate } from 'react-router-dom';

const AutoNavigateLink = () => {
    const navigate = useNavigate();
    const [isAutoNav, setAutoNav] = useState(true)
    const urls = [
        '/',
        '/MasterDataTransfer',
        '/Report',
    ]

    objInterval(() => {
        if (isAutoNav === true) {
            let currentUrl = window.location.pathname
            currentUrl = currentUrl.replace('DataTransferMonitor', '').replace('//', '/')

            urls.map((link, index) => {
                console.log('currentUrl', currentUrl, `link${index}: `, link)
                if (link.toLowerCase() === currentUrl.toLowerCase()) {
                    console.log(urls[index === urls.length - 1 ? 0 : index + 1])
                    navigate(urls[index === urls.length - 1 ? 0 : index + 1])
                }
            })
        }
    }, isAutoNav === true ? 60000 : null);

    const onLinkClick = () => {
        let flag = !isAutoNav
        setAutoNav(flag)
    }

    return (
        <>
            <img className={isAutoNav === true ? 'reloadButton rotate' : 'reloadButton'}
                onClick={onLinkClick}
                src={`${process.env.PUBLIC_URL}/reload.png`} alt='Auto Navigation' title={isAutoNav === true ? 'Click to stop Auto Page Navigation' : 'Click to start Auto Page Navigation'} />
            <span className='separator'></span>
        </>
    )
}

export default AutoNavigateLink