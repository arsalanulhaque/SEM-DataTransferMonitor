import React, { useState, useEffect, useContext, } from 'react';
import { SocketContext } from '../context/Socket';

const Clock = () => {
    const socket = useContext(SocketContext);
    const [clock, setClock] = useState("");

    useEffect(() => {
        const timerEvent = (time) => {
            setClock(time)
        }

        socket.on('timerEvent', timerEvent);
        // CLEAN UP THE EFFECT
        return () => {
            socket.off('timerEvent', timerEvent)
        }
    }, [socket, setClock]);

    return (
        <span id='clock'>{clock}</span>
    )
}

export default Clock;