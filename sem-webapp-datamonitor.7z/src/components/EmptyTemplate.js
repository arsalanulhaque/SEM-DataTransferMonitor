import React from 'react';
import "../../node_modules/bootstrap/dist/css/bootstrap.min.css";

const EmptyTemplate = () => {
    return (

        <div className="d-flex flex-column align-items-center justify-content-center h-100">
            <img src={`${process.env.PUBLIC_URL}/sleeping.png`} className=".empty-icon" alt="" />
            <p className='empty-text flex'>No results found!</p>
        </div >
    )
}

export default EmptyTemplate;