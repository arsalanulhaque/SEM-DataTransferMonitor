import { useState, useEffect, useContext } from 'react';
import '../App.css';
import { SocketContext, forceReconnect } from '../context/Socket'

function ErrorDialog() {

    const socket = useContext(SocketContext)
    const [error, setError] = useState('')

    useEffect(() => {
        const getServerError = (data) => {
            if (data)
                if (data.error) {
                    setError(data)
                }
                else {
                    setError(null)
                }
        }
        const onReloadBrowser = (data) => {
            let msg = {
                error: true,
                title: 'Alert!',
                errorMsg: data,
            }
            getServerError(msg)
            forceReconnect()
        }

        const onConnectionClose = (data) => {
            data.error = true
            data.title = 'Error!'
            data.errorMsg = 'Connection Lost!'
            data.errorSource = 'Application server disconnected!'
            getServerError(data)
        }

        const onApiError = (data) => {
            if (data.errorMsg !== 'No data recieved from API!') {
                data.error = true
                data.title = 'API Response Error!'
                getServerError(data)
            }
        }

        socket.on('responseError', onApiError);
        socket.on('connect_error', onConnectionClose);
        socket.on('reloadBrowser', onReloadBrowser);

        // CLEAN UP THE EFFECT
        return () => {
            // socket.off('close', onConnectionClose);
            socket.on('reloadBrowser', onReloadBrowser);
        }
    }, [socket, setError])

    return (
        <div className={error.error ? 'error-dialog show' : 'error-dialog hide'} >
            <h2>{error.title}
            </h2>
            <p>{error.errorMsg}</p>
            {error?.errorSource ? `Error Source:${error?.errorSource}` : null}
        </div>
    );
}

export default ErrorDialog;