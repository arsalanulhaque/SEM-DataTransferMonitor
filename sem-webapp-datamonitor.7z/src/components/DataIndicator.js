

const DataIndicator = (props) => {
    return (
        <div className={props.state === true ? "connected" : "disconnected"}></div>
    )
}

export default DataIndicator;
