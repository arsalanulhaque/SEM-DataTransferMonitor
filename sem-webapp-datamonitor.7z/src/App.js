import './App.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { SocketContext, socket } from './context/Socket';
import { SessionContext, clientSession } from './context/Session';
import DataTransferMonitor from './pages/dataTransferMonitor/DataTransferMonitor';
import MasterDataTransfer from './pages/masterDataTransfer/MasterDataTransfer';
import DataTransferDetails from './pages/dataTransferDetails/DataTransferDetails';
import Report from './pages/report/Report';
import ErrorPage from './ErrorPage';
import { useEffect, useState } from 'react';
import SessionInstance from "./context/Session"


function App() {
    // creating a local state
    const objSession = SessionInstance.getSession()
    const [session, setClientSession] = useState(objSession);
    console.log('public url: ', window.location.href.includes('localhost:') ? '/' : process.env.PUBLIC_URL)

    useEffect(() => {
        setClientSession(objSession)
    }, [window])


    return (
        <SocketContext.Provider value={socket}>
            <SessionContext.Provider value={{ session, setClientSession }}>
                <div className="App" >
                    <BrowserRouter basename={window.location.href.includes('localhost:') ? '/' : process.env.PUBLIC_URL}>
                        <Routes>
                            <Route index path="/" element={<DataTransferMonitor />} />
                            <Route path="/MasterDataTransfer" element={<MasterDataTransfer />} />
                            <Route path="/DataTransferDetails/:system/:id" element={<DataTransferDetails />} />
                            <Route path="/Report" element={<Report />} />
                            <Route path="*" element={<ErrorPage />} />
                        </Routes>
                    </BrowserRouter>
                </div>
            </SessionContext.Provider>
        </SocketContext.Provider>
    )
}

export default App;