function ErrorPage() {
    return (
        <div className="App" >
            Hey!! You break the application!!
        </div>
    );
}

export default ErrorPage;