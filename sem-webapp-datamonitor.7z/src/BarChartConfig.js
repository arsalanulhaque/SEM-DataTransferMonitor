export function chartData() {
    return {
        labels: ['One Week', '2 Weeks', '3 Plus Weeks'],
        datasets: [{
            data: [0, 0, 0],
            label: '',
            backgroundColor: ['rgba(255, 220, 0, 0.2)', 'rgba(255, 185, 0, 0.2)', 'rgba(255, 0, 0, 0.2)'],
            borderColor: ['rgb(255, 220, 0)', 'rgb(255, 165, 0)', 'rgb(255, 0, 0)'],
            borderWidth: 1
        }]
    }
}

export function chartOptions() {
    return {
        responsive: true,
        maintainAspectRatio: false,
        data: chartData,
        plugins: {
            legend: {
                display: false
            },
        },

        animation: {
            onComplete: function () {
                let ctx = this.ctx;
                let chartinst = this;
                // ctx.font = Chart.helpers.fontString(Chart.defaults.font.size, Chart.defaults.font.style, Chart.defaults.font.family);
                ctx.textAlign = 'center';
                ctx.textBaseline = 'bottom';

                this.data.datasets.forEach(function (dataset, i) {
                    if (chartinst.isDatasetVisible(i)) {
                        var meta = chartinst.getDatasetMeta(i);
                        meta.data.forEach(function (bar, index) {
                            var data = dataset.data[index];
                            if (bar.height > 20)
                                ctx.fillText(data, bar.x, bar.y + 17);
                            else
                                ctx.fillText(data, bar.x, bar.y - 2);
                        });
                    }
                });
            }
        }
    }
}
