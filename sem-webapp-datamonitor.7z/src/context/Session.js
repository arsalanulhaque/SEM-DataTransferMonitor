import { v4 as uuidv4 } from 'uuid';
import { bake_cookie, read_cookie, } from 'sfcookies'
import { setDate } from '../helper'
import React from 'react';

export const clientSession = {
    dashboardID: 'DataTransferMonitor',
    sessionID: '',
    socketID: '',
    events: [],
    startDate: setDate(Date.now(), -7, false),
    endDate: setDate(Date.now(), 1, false),
    filterName: '7days',
    docType: [],
    contentType: [],
    status: [],
    addEvent: (eventName, removeAll = true) => {
        if (removeAll === true) clientSession.events = []
        if (clientSession.events?.find(event => event === eventName) === undefined) {
            clientSession.events.push(eventName)
        }
        return clientSession.events
    },
    removeAllEvents: () => {
        return clientSession.events = []
    },
    removeEvent: (eventName) => {
        if (clientSession.events?.find(event => event === eventName) !== undefined) {
            clientSession.events = clientSession.events?.find(event => event !== eventName)
        }
    },

}

var SessionInstance = null

const getCookie = (name) => {
    let cookie = read_cookie(name)
    if (cookie.length > 0) {
        return cookie
    }
    else {
        let uuid = uuidv4()
        bake_cookie(name, uuid)
        getCookie(name)
    }
}
getCookie('DTM-Session')

class Session {
    constructor() {
        if (SessionInstance === null) {
            if (clientSession.sessionID === '') {
                clientSession.sessionID = getCookie('DTM-Session')
            }
        }
    }

    getSession = () => {
        return clientSession
    }

    setSocketID = (socketID) => {
        clientSession.socketID = socketID
    }
    setStartDate = (startDate) => {
        clientSession.startDate = setDate(startDate, 0, false)
    }
    setEndDate = (endDate) => {
        clientSession.endDate = setDate(endDate, 0, false)
    }
    setFilterName = (filterName) => {
        clientSession.filterName = filterName
    }
    // addEvent = (eventName) => {
    //     if (clientSession?.events?.find(event => event === eventName) === undefined)
    //         clientSession.events.push(eventName)
    // }
    // removeAllEvents = () => {
    //     clientSession.events = []
    // }
    resetFilters = () => {
        clientSession.startDate = setDate(Date.now(), 0, false)
        clientSession.endDate = setDate(Date.now(), 0, false)
        clientSession.filterName = 'today'
    }
}


SessionInstance = new Session()
export const SessionContext = React.createContext(clientSession);
export default SessionInstance
