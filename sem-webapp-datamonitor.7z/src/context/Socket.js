import React from "react"
import socketio from "socket.io-client"
import SessionInstance from "./Session"

const ENDPOINT = process.env.REACT_APP_API_URL

export const socket = socketio.connect(ENDPOINT)
export const SocketContext = React.createContext(socket)
export const forceReconnect = () => {
    setTimeout(() => {
        if (window.location.href.includes(':787')) {
            let path = window.location.pathname.replace('/', '')
            window.location.assign('https://semlive/DataTransferMonitor/' + path)
        }
        window.location.reload(false)
    }, 10000)
}

initConnection()

export function initConnection() {
    socket.on('connect', function () {
        SessionInstance.setSocketID(socket.id)
        console.log(socket.id)

        console.log("socket connection successful!", new Date(), SessionInstance.getSession())
        socket.emit('registerClient', SessionInstance.getSession())
        socket.emit('create', 'DataTransferMonitor');
    })

    socket.io.on("close", function () {
        console.log("socket connection closed!", new Date())

        forceReconnect()
    })

    socket.on('disconnect', function () {
        console.log("socket disconnected from", new Date())
        socket.removeAllListeners()
        socket.volatile.emit('unregisterClient', SessionInstance.getSession())
        socket.disconnect()
        socket.timeout(5000).connect()
    })

    socket.on("connect_error", (error) => {
        console.log("socket connection error", new Date())
        forceReconnect()
    })

    socket.on("error", (error) => {
        console.log("socket connection error", new Date())
        forceReconnect()
    })

    socket.on("refreshWindow", function () {
        console.log("Reload application requested at:", new Date())
        forceReconnect()
    })

    socket.on("updateClientUrl", function (url) {
        let path = window.location.pathname.replace('/', '')
        window.location.assign(url + path)
    })
}