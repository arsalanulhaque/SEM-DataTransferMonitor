import { useEffect, useState, useContext, } from "react";
import { SocketContext } from '../../../context/Socket';
import { SessionContext } from "../../../context/Session"

export const useData = () => {
    const { session } = useContext(SessionContext)
    const socket = useContext(SocketContext)
    const [objData, setData] = useState([]);

    useEffect(() => {
        if (objData?.length === 0) {
            let events = session.events.find(e => e === 'Report')
            if (!events) {
                session.events = session.addEvent('Report')
                socket.emit('updateDTMSession', session)
            }
            else {
                session.events = session.removeAllEvents()
                socket.emit('updateDTMSession', session)
            }
        }

        const getData = (resp) => {
            if (resp) {
                if (resp?.data?.length > 0 && objData?.length === 0) {
                    setData(resp)
                    session.events = session.removeAllEvents()
                    socket.emit('updateDTMSession', session)
                }
            }
        }

        socket.on('Report', getData);

        // CLEAN UP THE EFFECT
        return () => {
            socket.off('Report', getData());
        }
    }, [socket, session, objData,]);

    return { objData }
}