import { useState, useEffect } from "react";

export function useYearFilter() {
    const curYear = (new Date()).getFullYear()
    const [yearList, setYearList] = useState([])
    const [selectedYear, setSelectedYear] = useState([{ label: curYear, value: curYear }])

    useEffect(() => {
        let years = []
        for (let index = 0; index < 3; index++) {
            let year = curYear - index
            let item = { label: year, value: year }
            years.push(item)
        }
        setYearList(years)
    }, [setYearList])

    const handleDateChange = (id, items) => {
        setSelectedYear(items);
    };

    return { yearList, selectedYear, handleDateChange };
}