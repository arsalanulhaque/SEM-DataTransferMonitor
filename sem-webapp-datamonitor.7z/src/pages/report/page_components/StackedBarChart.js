import React, { useEffect, useState, } from "react";
import Chart from 'chart.js/auto'; //Required to register Chart dependencies (Don`t remove)
import { Bar } from 'react-chartjs-2'; // 
import 'chartjs-plugin-datalabels'
import zoomPlugin from "chartjs-plugin-zoom";
import EmptyTemplate from "../../../components/EmptyTemplate"
import { ChartUiConfigs as ChartUi } from './ChartUiConfig'
import ChartConfigService from './ChartConfigService';

function StackedBarChart({ chartData, filters }) {
    Chart.register(zoomPlugin);

    const [objChart, setChart] = useState({ labels: [], datasets: [], chartOptions: { options: {} } });

    useEffect(() => {
        if (chartData?.data?.length > 0) {
            let tempdata = JSON.parse(JSON.stringify(chartData))
            tempdata.selectedYears = filters.years
            tempdata.ewStatus = filters.ewStatus
            let obj = ChartConfigService(tempdata, ChartUi.lineChartConfig)
            setChart(obj)
        }
    }, [chartData, filters, filters.years, filters.ewStatus])

    return (
        <>
            {
                objChart?.labels?.length > 0 ?
                    <Bar data={{ labels: objChart?.labels, datasets: objChart?.datasets }} options={objChart?.chartOptions?.options} />
                    : <EmptyTemplate />
            }
        </>
    );
}

export default StackedBarChart;