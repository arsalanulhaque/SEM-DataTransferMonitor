import { getByKey, getJsonObjsArrayByKey, sortArrayObjByKey } from "../../../helper";

const ChartConfigService = (data, config) => {
    data = getData(data, config);

    let Feedback_of_WO_State = getLineObject("Feedback of WO State", null, null, null, null, false, 0.1, "#d40f29", "#d40f29", "butt", [], 0.0, "miter", "#d40f29", "#fff", 1, 5, "#d40f29", "rgba(220,220,220,1)", 2, 0, 10, data.Feedback_of_WO_State);
    let Order_State = getLineObject("Order State", null, null, null, null, false, 0.1, "#FFA500", "#FFA500", "butt", [], 0.0, "miter", "#FFA500", "#fff", 1, 5, "#FFA500", "rgba(220,220,220,1)", 2, 0, 10, data.Order_State);
    let Serial_No_Transfer = getLineObject("Serial No. Transfer", null, null, null, null, false, 0.1, "#3d85c6", "#3d85c6", "butt", [], 0.0, "miter", "#3d85c6", "#fff", 1, 5, "#3d85c6", "rgba(220,220,220,1)", 2, 0, 10, data.Serial_No_Transfer);
    let Work_Order = getLineObject("Work Order", null, null, null, null, false, 0.1, "#999999", "#999999", "butt", [], 0.0, "miter", "#999999", "#fff", 1, 5, "#999999", "rgba(220,220,220,1)", 2, 0, 10, data.Work_Order);

    let line = lineOptions(config.chartOptions)
    let output = {
        chartOptions: line,
        labels: data.BOOK_DATE, //required for chart x-axis
        datasets: [Feedback_of_WO_State, Order_State, Serial_No_Transfer, Work_Order], //charts data
    };
    return output;


    function getData(data, config) {

        if (!data || data?.length === 0)
            return

        let tempData = []
        let years = data?.selectedYears.sort(sortArrayObjByKey('value'))

        years?.forEach((item) => {
            tempData = tempData.concat(data.data.filter(row => row.WeekYear.split('/')[1].toString() === item.value.toString()))
        })

        if (tempData.length > 0) {

            tempData = tempData.map(o => {
                o.Year = o.WeekYear.split('/')[1]
                return o
            });

            tempData = tempData.sort(sortArrayObjByKey('WeekNo'))
            tempData = tempData.sort(sortArrayObjByKey('Year'))
            // tempData = sortArrayObjByDate(tempData, 'WeekYear', true)
            data.data = tempData
        }

        //initializing empty arrays for required lines to draw on chart
        let [objFBOWOS, objOS, objSNT, objWO] = [[], [], [], []]

        //preparing data for each line to draw on chart
        objFBOWOS = getByKey(data.data.filter(d => d.Category === 'Feedback of WO State' && d.EWStatus == data.ewStatus), "Total")
        objOS = getByKey(data.data.filter(d => d.Category === 'Order State' && d.EWStatus == data.ewStatus), "Total")
        objSNT = getByKey(data.data.filter(d => d.Category === 'Serial No. Transfer' && d.EWStatus == data.ewStatus), "Total")
        objWO = getByKey(data.data.filter(d => d.Category === 'Work Order' && d.EWStatus == data.ewStatus), "Total")

        // config.chartOptions.min = parseFloat(objLL[0]) - 1;
        // config.chartOptions.max = parseFloat(objUL[0]) + 1;

        let labels = getJsonObjsArrayByKey(data.data, "WeekYear")
        let dataset = {
            "Feedback_of_WO_State": objFBOWOS,
            "Order_State": objOS,
            "Serial_No_Transfer": objSNT,
            "Work_Order": objWO,
            // UPPER_LIMIT: objUL,
            // MEASURE_VALUE: objMV,
            BOOK_DATE: labels,
            // PART_NUMBER: getByKey(data, "PART_NUMBER"),
            // SERIAL_NUMBER: getByKey(data, "SERIAL_NUMBER"),
            // STATION_NUMBER: getByKey(data, "STATION_NUMBER"),
            // INDEX: getByKey(data, "INDEX")
        }

        return dataset;
    }

    function getLineObject(label, lowerBoundLimit, upperBoundLimit, lowerWarningLimit, upperWarningLimit, fill, lineTension, backgroundColor, borderColor, borderCapStyle,
        borderDash, borderDashOffset, borderJoinStyle, pointBorderColor, pointBackgroundColor, pointBorderWidth, pointHoverRadius, pointHoverBackgroundColor, pointHoverBorderColor,
        pointHoverBorderWidth, pointRadius, pointHitRadius, data, lstParts, lstSerials) {

        // const lowerLimit = (ctx, value) => ctx.p1.parsed.y < lowerBoundLimit ? value : undefined;
        // const upperLimit = (ctx, value) => ctx.p1.parsed.y > upperBoundLimit ? value : undefined;
        // const lowerWarning = (ctx, value) => ctx.p1.parsed.y < lowerWarningLimit ? value : undefined;
        // const upperWarning = (ctx, value) => ctx.p1.parsed.y > upperWarningLimit ? value : undefined;

        return {
            label: label,
            fill: fill,
            lineTension: lineTension,
            backgroundColor: backgroundColor,
            borderColor: borderColor,
            // segment: {
            //     borderColor: ctx => {
            //         if (label === "Measure Value")
            //             return lowerLimit(ctx, "#fa6102") || upperLimit(ctx, "#fa6102") || lowerWarning(ctx, "#FFA500") || upperWarning(ctx, "#FFA500")
            //     }
            // },

            borderCapStyle: borderCapStyle,
            borderDash: borderDash,
            borderDashOffset: borderDashOffset,
            borderJoinStyle: borderJoinStyle,
            pointBorderColor: pointBorderColor,
            pointBackgroundColor: pointBackgroundColor,
            pointBorderWidth: pointBorderWidth,
            pointHoverRadius: pointHoverRadius,
            pointHoverBackgroundColor: pointHoverBackgroundColor,
            pointHoverBorderColor: pointHoverBorderColor,
            pointHoverBorderWidth: pointHoverBorderWidth,
            pointRadius: pointRadius,
            pointHitRadius: pointHitRadius,
            data: data,
            // lstParts: lstParts,
            // lstSerials: lstSerials
        }
    }

    function lineOptions(chartOptions) {
        return {
            options: {
                type: "bar",
                responsive: true,
                maintainAspectRatio: 1,

                plugins: {
                    title: {
                        display: true,
                        text: chartOptions.title,
                        color: "black",
                        position: "top",
                        align: "center",    //start / center / end
                        font: {
                            size: 26,
                            weight: "bold",
                        }
                    },
                    legend: {
                        display: true,
                        position: 'left',
                        align: 'end',
                        labels: {
                            color: "black",
                            boxWidth: 10,
                            boxHeight: 10,
                            font: {
                                size: 15,

                            }
                        }
                    },
                    tooltip: {
                        // callbacks: {
                        //     footer: (tooltipItems) => {
                        //         let partNo = null;
                        //         let serialNo = null;
                        //         tooltipItems.forEach(function (tooltipItem) {
                        //             if (tooltipItem.datasetIndex === 2) {
                        //                 partNo = tooltipItem.dataset.lstParts[tooltipItem.dataIndex]
                        //                 serialNo = tooltipItem.dataset.lstSerials[tooltipItem.dataIndex]
                        //             }
                        //         });
                        //         if (partNo !== null && serialNo !== null)
                        //             return `Part No: ${partNo} \nSerial No: ${serialNo}`;
                        //     }
                        // }
                    },
                    zoom: {
                        pan: {
                            enabled: true,
                            mode: "xy",
                            threshold: 10
                        },
                        zoom: {
                            wheel: {
                                enabled: true
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        type: "category",
                        stacked: true,
                        ticks: {
                            autoSkipPadding: 1,
                        },
                        display: true,
                        position: "right",
                        title: {
                            display: true,
                            text: chartOptions.xAxisTitle,
                            color: "black",
                            font: {
                                size: 20,
                                weight: "bold",
                            }
                        },
                        grid: {
                            drawOnChartArea: false, // only want the grid lines for one axis to show up
                        }
                    },
                    y: {
                        display: true,
                        title: {
                            stacked: true,
                            display: true,
                            text: chartOptions.yAxisTitle,
                            color: "black",
                            font: {
                                size: 20,
                                weight: "bold",
                            }
                        },
                        // min: chartOptions.min === 0 ? null : chartOptions.min,
                        // max: chartOptions.max === 0 ? null : chartOptions.max,
                        // grid: {
                        //     drawOnChartArea: false, // only want the grid lines for one axis to show up
                        //   }
                    }
                },
            }
        }
    }
};


const getdoughnutData = (data, config) => {
    var obj = {
        warningBackgroundColor: "",
        labels: [],
        datasets: [
            {
                label: "Percent: ",
                data: [],
                backgroundColor: [],
                borderColor: [
                    // "#3d85c6", //green
                    // "#FFA500", //yellow
                    // "#fa6102", //orange
                    // "#d40f29", //red
                    // "#fa6102",
                ],
                borderWidth: 0
            }
        ],
        options: {
            plugins: {
                legend: {
                    display: true,
                    fullSize: true,
                    position: "left",
                    align: "left",
                    maxWidth: 300,
                    labels: {
                        boxHeight: 10,
                        boxWidth: 10,
                        textAlign: "left",
                        font: {
                            size: 20,
                            weight: "bold",
                        }
                    }
                },
                datalabels: {
                    borderRadius: 0,
                    formatter: (val, ctx) => {
                        console.log("val:", val);
                        return ctx.chart.data.labels[ctx.dataIndex];
                    },
                }
            },

        }
    };

    let [countOL, countUWB, countNormal, countLWB, countUL, countVariation] = [0, 0, 0, 0, 0, 0];
    let overLimit = data.UPPER_LIMIT[0];
    let upperWarning = data.UPPER_WARNING[0];
    let lowerWarning = data.LOWER_WARNING[0];
    let underLimit = data.LOWER_LIMIT[0];
    let totalCount = data.MEASURE_VALUE.length;

    data.MEASURE_VALUE.forEach((mv, index) => {

        if (mv >= overLimit) countOL = countOL + 1; // Over Limit
        else if (mv >= upperWarning && mv < overLimit) countUWB = countUWB + 1; //upper warning zone
        else if (mv > lowerWarning && mv < upperWarning) countNormal = countNormal + 1; //normal zone
        else if (mv > underLimit && mv <= lowerWarning) countLWB = countLWB + 1; //Lower warning zone
        else if (mv <= underLimit) countUL = countUL + 1; //Under limit
        else { countVariation = countVariation + 1; }
    });

    countOL = (countOL / totalCount) * 100;
    countUWB = (countUWB / totalCount) * 100;
    countNormal = (countNormal / totalCount) * 100;
    countLWB = (countLWB / totalCount) * 100;
    countUL = (countUL / totalCount) * 100;
    countVariation = (countVariation / totalCount) * 100;

    if (countOL > 0) {
        obj.labels.push("Upper Limit: " + countOL.toFixed(2) + "%");
        obj.datasets[0].data.push(countOL);
        obj.datasets[0].backgroundColor.push("#fa6102");
    }
    if (countUWB > 0) {
        obj.labels.push("Upper Warning: " + countUWB.toFixed(2) + "%");
        obj.datasets[0].data.push(countUWB)
        obj.datasets[0].backgroundColor.push("#FFA500");
    }
    if (countNormal > 0) {
        obj.labels.push("Normal: " + countNormal.toFixed(2) + "%");
        obj.datasets[0].data.push(countNormal)
        obj.datasets[0].backgroundColor.push("#3d85c6");
    }
    if (countLWB > 0) {
        obj.labels.push("Lower Warning: " + countLWB.toFixed(2) + "%");
        obj.datasets[0].data.push(countLWB)
        obj.datasets[0].backgroundColor.push("#FFA500");
    }
    if (countUL > 0) {
        obj.labels.push("Lower Limit: " + countUL.toFixed(2) + "%");
        obj.datasets[0].data.push(countUL)
        obj.datasets[0].backgroundColor.push("#fa6102");
    }
    if (countVariation > 0) {
        obj.labels.push("Variation: " + countVariation.toFixed(2) + "%");
        obj.datasets[0].data.push(countVariation)
        obj.datasets[0].backgroundColor.push("silver");
    }

    //warning color
    if ((countUWB + countLWB) > 10)
        obj.warningBackgroundColor = "yellow"

    return obj;
}

export default ChartConfigService;