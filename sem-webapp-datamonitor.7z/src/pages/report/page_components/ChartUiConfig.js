
export const ChartUiConfigs = {
    lineChartConfig: {
        chartOptions: {
            id: "Line_Chart",
            title: "Status Type By Week",
            max: 15,
            min: 5,
            xAxisTitle: "Weeks",
            yAxisTitle: "Counts",
        },
    },
}