import React, { useState, useCallback, } from "react";
import Header from '../../components/Header';
// import LineChart from "./page_components/LineChart"
import StackedBarChart from "./page_components/StackedBarChart"

import Dropdown from '../../controls/Dropdown'
import DataIndicator from "../../components/DataIndicator"
import { useData } from "./hooks/useData";
import { useYearFilter } from "./hooks/useYearFilter";

const Report = () => {
    const { objData } = useData();
    const [ewStatus, setEwStats] = useState(-2)
    const { yearList, selectedYear, handleDateChange } = useYearFilter();

    //on ewStatus changed
    const onChange = useCallback((args) => {
        setEwStats(args)
        // setData({ ...objData, ewStatus: args })
    }, [setEwStats]);

    return (
        <div className="container-fluid">
            <Header title="Transfer Monitor ERP <> MES" />

            <div className="card  mt-2">
                <div className="card-header">
                    <h3>Report</h3>
                    <DataIndicator state={objData?.data?.length > 0} />
                </div>
                <div id="tblCardBody" className="card-body h-100" >

                    <div className="row">
                        <div className="col-1">

                            <div className="fs-6 fst-italic text-muted p-1 ">Filter by Year:</div>
                            <div className="gap-2 d-md-flex">
                                <Dropdown id='ddlYears' label={''}
                                    list={yearList} onValueChange={handleDateChange} style='fs-6 w-100'
                                    selectedValue={selectedYear} enableSelectAll={true} closeonChange={false} />
                            </div>

                            <div className="fs-6 fst-italic text-muted p-1 ">Filter by status:</div>
                            <div className="gap-2 d-md-flex">
                                <button className={ewStatus === -2 ? "btn btn-sm btn-primary m-1" : "btn btn-sm btn-outline-dark m-1"}
                                    type="button" onClick={() => {
                                        onChange(-2)
                                    }}>Failed</button>

                                <button className={ewStatus === 2 ? "btn btn-sm btn-primary m-1" : "btn btn-sm btn-outline-dark m-1"}
                                    type="button" onClick={() => {
                                        onChange(2)
                                    }}>Passed</button>
                            </div>


                        </div>
                        <div className="col">
                            <StackedBarChart
                                chartData={objData}
                                filters={{ years: selectedYear, ewStatus: ewStatus }}
                            />
                        </div>

                    </div>
                </div>
            </div>
        </div>
    )
}

export default Report;