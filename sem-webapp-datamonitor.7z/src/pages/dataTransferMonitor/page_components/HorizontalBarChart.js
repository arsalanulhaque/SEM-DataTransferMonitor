import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom'
import Chart from 'chart.js/auto'; //Required to register Chart dependencies (Don`t remove)
import { Bar, getElementsAtEvent } from 'react-chartjs-2'; // 
import _ from "lodash";
import 'chartjs-plugin-datalabels'
import EmptyTemplate from "../../../components/EmptyTemplate"
import DataIndicator from "../../../components/DataIndicator"

const HorizontalBarChart = ({ title, category, system, data }) => {
    const [apiData, setApiData] = useState([]);

    const chartRef = useRef();


    let chartData = {
        labels: ['Queue', 'Passed', 'Failed'],
        datasets: [
            {
                id: category,
                sys: system,
                data: [0],
                backgroundColor: ['rgba(0,177,248)', 'rgba(0,128,0)', 'rgba(255, 0, 0)',],
                barPercentage: 1,
            },
        ]
    };

    let chartConfig = {
        responsive: true,
        indexAxis: 'y', //horizontal bar chart
        maintainAspectRatio: false,
        data: chartData,
        tooltips: { enabled: false },
        hover: { mode: null },

        plugins: {
            legend: {
                display: false
            },
            title: {
                display: false,
                text: title,
                position: 'bottom'
            },
            tooltip: {
                enabled: false,
            },
        },

        scales: {
            x: {
                grid: {
                    display: false,
                },
            },
            y: {
                grid: {
                    offset: true
                },
            },
        },

        animation: {
            onComplete: function () {
                let ctx = this.ctx;
                let chartinst = this;
                ctx.textAlign = 'center';
                ctx.textBaseline = 'bottom';

                this.data.datasets.forEach(function (dataset, i) {
                    if (chartinst.isDatasetVisible(i)) {

                        var meta = chartinst.getDatasetMeta(i);
                        meta.data.forEach(function (bar, index) {
                            let labelText = dataset.label[index]
                            let value = dataset.data[index]
                            let vCenterLable = 1.3
                            let centerLabel = (ctx.measureText(labelText).width / (labelText.toString().length * 0.4)) + (chartinst.chartArea.width / 2)

                            if (index === 0) {
                                vCenterLable = bar.height * 1.45
                                centerLabel = (ctx.measureText(labelText).width + chartinst.chartArea.width / 1.695)
                            }
                            else if (index === 1) {
                                vCenterLable = bar.y * 1.27
                            }
                            else if (index === 2) {
                                vCenterLable = bar.y * 1.17
                            }

                            ctx.fillStyle = (value >= 40 && value <= 55 ? '#000' : value > 55 ? '#fff' : dataset.backgroundColor[index])
                            ctx.font = `${bar.height}px "Helvetica Neue", Helvetica, Arial, sans-serif`
                            ctx.fillText(labelText, centerLabel, vCenterLable)
                        });
                    }
                });
            }
        }
    }

    useEffect(() => {
        let filteredData = data.filter(rows => rows.CATEGORY === category)[0]
        if (filteredData) {
            chartData.datasets[0].data = [filteredData.QUEUE_PERCENT, filteredData.PASSED_PERCENT, filteredData.FAILED_PERCENT, filteredData.TOTAL_PERCENT]
            chartData.datasets[0].label = [filteredData.QUEUE_QTY, filteredData.PASSED_QTY, filteredData.FAILED_QTY, filteredData.TOTAL_QTY]
            chartConfig.data = chartData

            if (_.has(chartConfig.data, 'datasets')) {
                setApiData(chartConfig)
            }
        } else {
            setApiData([])
        }

    }, [data]);


    return (
        <>
            <div className="card h-100" >
                <div className="card-header">
                    <h3 >{title}</h3>
                    <DataIndicator state={_.has(apiData, 'data')} />
                </div>
                <div className="card-body" >
                    {_.has(apiData, 'data') ?
                        <Link to={`/DataTransferDetails/${chartData.datasets[0].sys}/${chartData.datasets[0].id}`} >
                            <Bar key="barChart" ref={chartRef} datasetIdKey='id' options={apiData} data={apiData.data} />
                        </Link> :
                        <EmptyTemplate />}
                </div>
            </div>
        </ >
    )
}

export default HorizontalBarChart;