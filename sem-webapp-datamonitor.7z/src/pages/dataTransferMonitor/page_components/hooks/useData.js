import { useEffect, useState, useContext, } from "react";
import { SocketContext } from '../../../../context/Socket';
import { SessionContext } from "../../../../context/Session"

export const useData = () => {
    const socket = useContext(SocketContext)
    const { session, setClientSession } = useContext(SessionContext)
    const [objData, setData] = useState([]);

    useEffect(() => {
        let event = session.events.find(e => e === 'MiiJHWorksQueueCount')
        if (objData?.length === 0 && !event) {
            setClientSession({ ...session, events: session.addEvent('MiiJHWorksQueueCount', false) })
            socket.emit('updateDTMSession', session)
        }

        const getData = (resp) => {
            if (resp) {
                let data = resp.data
                setData(data)
                console.log(`data received from api: ${data.length}`)
            }
        }

        socket.on('MiiJHWorksQueueCount', getData);

        // CLEAN UP THE EFFECT
        return () => {
            socket.off('MiiJHWorksQueueCount', getData());
        }
    }, [socket, objData,])

    return { objData }
}