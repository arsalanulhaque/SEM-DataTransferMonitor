import React, { useState, useContext, useEffect } from 'react'
import "../../../node_modules/bootstrap/dist/css/bootstrap.min.css"
import Header from '../../components/Header'
import HorizontalBarChart from './page_components/HorizontalBarChart'
import GlobalFilters from '../../components/GlobalFilters'
import { SessionContext } from "../../context/Session"
import { SocketContext } from '../../context/Socket';

const DataTransferMonitor = () => {

    const socket = useContext(SocketContext)
    const { session, setClientSession } = useContext(SessionContext)
    const [apiData, setApiData] = useState([])



    useEffect(() => {
        let events = session.events.find(e => e === 'MiiJHWorksQueueCount')
        if (!events) {
            // session.removeAllEvents()
            // session.addEvent('MiiJHWorksQueueCount')
            setClientSession({ ...session, events: session.addEvent('MiiJHWorksQueueCount', false), })
            socket.emit('updateDTMSession', session)
        }

        const getQueue = (data) => {
            if (data) {
                data = data.data
                setApiData(data)
                console.log(`data received from api: ${data.length}`)
            }
        }

        socket.on('MiiJHWorksQueueCount', getQueue)


        // CLEAN UP THE EFFECT
        return () => {
            socket.off('MiiJHWorksQueueCount', getQueue());
        }
    }, [socket.id, session.events, apiData]);

    return (
        <div className="container-fluid">
            <Header title="DATA TRANSFER MONITOR" />
            <GlobalFilters />

            <div className="mt-1 row h-25">
                <div className='col-4'>
                    <HorizontalBarChart title='MII - General' category='MiiGeneral' system='MII' data={apiData} />
                </div>
                <div className='col-4'>
                    <HorizontalBarChart title='MII - Work Orders' category='MiiWorkOrder' system='MII' data={apiData} />
                </div>
                <div className='col-4'>
                    <HorizontalBarChart title='MII - Work Orders Confirmation' category='MiiWorkOrdersConfirmation' system='MII' data={apiData} />
                </div>
            </div>

            <div className="mt-1 row h-25">
                <div className='col-4'>
                    <HorizontalBarChart title='MII - Serial Numbers' category='MiiSerialNumbers' system='MII' data={apiData} />
                </div>
                <div className='col-4'>
                    <HorizontalBarChart title='MII - Serial Numbers Received' category='MiiReceivedSerialNumbers' system='MII' data={apiData} />
                </div>
                <div className='col-4'></div>
            </div>

            <div className="mt-1 row h-25">
                <div className='col-4'>
                    <HorizontalBarChart title='JHWorks - General' category='JHWorksGeneral' system='JHWorks' data={apiData} />
                </div>
                <div className='col-4'>
                    <HorizontalBarChart title='JHWorks - Work Orders' category='JHWorksWorkOrder' system='JHWorks' data={apiData} />
                </div>
                <div className='col-4'>
                    <HorizontalBarChart title='JHWorks - Work Orders Confirmation' category='JHWorksConfirmWorkOrder' system='JHWorks' data={apiData} />
                </div >
            </div >
        </div >
    )
}

export default DataTransferMonitor