import "../../../node_modules/bootstrap/dist/css/bootstrap.min.css"
import Header from '../../components/Header'
import HorizontalBarChart from './page_components/HorizontalBarChart'
import GlobalFilters from '../../components/GlobalFilters'


const DataTransferMonitor = () => {


    return (
        <div className="container-fluid">
            <Header title="DATA TRANSFER MONITOR" />
            <GlobalFilters />

            <div className="mt-1 row h-25">
                <div className='col-4'>
                    <HorizontalBarChart title='MII - General' category='MiiGeneral' system='MII' />
                </div>
                <div className='col-4'>
                    <HorizontalBarChart title='MII - Work Orders' category='MiiWorkOrder' system='MII' />
                </div>
                <div className='col-4'>
                    <HorizontalBarChart title='MII - Work Orders Confirmation' category='MiiWorkOrdersConfirmation' system='MII' />
                </div>
            </div>

            <div className="mt-1 row h-25">
                <div className='col-4'>
                    <HorizontalBarChart title='MII - Serial Numbers' category='MiiSerialNumbers' system='MII' />
                </div>
                <div className='col-4'>
                    <HorizontalBarChart title='MII - Serial Numbers Received' category='MiiReceivedSerialNumbers' system='MII' />
                </div>
                <div className='col-4'></div>
            </div>

            <div className="mt-1 row h-25">
                <div className='col-4'>
                    <HorizontalBarChart title='JHWorks - General' category='JHWorksGeneral' system='JHWorks' />
                </div>
                <div className='col-4'>
                    <HorizontalBarChart title='JHWorks - Work Orders' category='JHWorksWorkOrder' system='JHWorks' />
                </div>
                <div className='col-4'>
                    <HorizontalBarChart title='JHWorks - Work Orders Confirmation' category='JHWorksConfirmWorkOrder' system='JHWorks' />
                </div >
            </div >
        </div >
    )
}

export default DataTransferMonitor