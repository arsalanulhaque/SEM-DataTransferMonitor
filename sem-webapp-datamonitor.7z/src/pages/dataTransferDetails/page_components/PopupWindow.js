import React, { useState, useEffect } from 'react'
import Modal from "react-bootstrap/Modal";
import "../../../../node_modules/bootstrap/dist/css/bootstrap.min.css"

const PopupWindow = ({ config }) => {

    return (

        <Modal show={config.isVisible}  >
            <div className='card'>
                <Modal.Header className='card-header fw-bold fs-5' >{config.title}</Modal.Header>
                <Modal.Body ><textarea rows="20" className='text-muted' style={{ border: 'none', width: '100%' }} readOnly defaultValue={config.content} /></Modal.Body>
                <Modal.Footer className='card-footer'><button className="btn btn-light" onClick={() => config.onXmlViewClick(false, null, null)}>Close</button></Modal.Footer>
            </div>
        </Modal >
    )
}

export default PopupWindow