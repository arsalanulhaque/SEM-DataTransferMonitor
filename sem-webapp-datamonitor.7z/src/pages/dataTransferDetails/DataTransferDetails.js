import React, { useContext, useState, useEffect, useRef } from 'react'
import "react-datepicker/dist/react-datepicker.css";
import Header from '../../components/Header'
import Dropdown from '../../controls/Dropdown'
import DataIndicator from '../../components/DataIndicator'
import DatePicker from "react-datepicker"
import GridView from '../../controls/GridView/GridView';
import PopupWindow from './page_components/PopupWindow'
import { setDate, getJsonObjsArrayByKey, sortArrayObjByDate, sortArrayObjByKey, filterArrayObjByKey } from '../../helper'
import { SocketContext } from '../../context/Socket';
import { useParams } from "react-router-dom";
import GlobalFilters from '../../components/GlobalFilters'
import { SessionContext } from "../../context/Session"
import { DocTypeMapping } from './DocTypeMapping'
import { parseInt, } from 'lodash';

const DataTransferDetails = () => {
    const lastApiDataCount = useRef(0);
    const { system, id } = useParams();
    const socket = useContext(SocketContext)
    const { session, setClientSession } = useContext(SessionContext)
    const [apiData, setApiData] = useState([]);
    const [filteredData, setFilteredData] = useState([]);
    const [docTypeList, setDocTypeList] = useState([])
    const [contentTypeList, setContentTypeList] = useState([])
    const [statusList, setStatusList] = useState([])
    const [popupModal, setPopupModal] = useState({ 'isVisible': false, 'content': null })

    //Popup Window Handler
    const onXmlViewClick = (isVisible, title, content) => {
        if (isVisible)
            setPopupModal({
                'isVisible': isVisible, 'title': title, 'content': content, onXmlViewClick: onXmlViewClick
            })
        else
            setPopupModal({ 'isVisible': isVisible, 'title': null, 'content': null, onXmlViewClick: null })
    }

    const MiiSchema = {
        columns: [
            { label: 'STATUS', field: 'STATUS', type: 'ReadOnly', css: 'col' },
            { label: 'IDENTIFIER', field: 'IDENTIFIER', type: 'ReadOnly', css: 'col' },
            { label: 'DOCUMENT TYPE', field: 'DOC_TYPE', type: 'ReadOnly', css: 'col', trunacteSize: 30, },
            { label: 'MESSAGE', field: 'MESSAGE', type: 'ReadOnly', dataType: 'ReadOnly', css: 'col', trunacteSize: 40, },
            { label: 'DATE/TIME', field: 'RECEIVED_DATE_TIME', type: 'ReadOnly', dataType: 'DateTime', css: 'col-2' },
            {
                label: '', type: 'Action', css: 'col-1',
                template: (rowIndex, obj) => {
                    return <div className="d-grid gap-2 d-md-flex justify-content-md-end">
                        <button id='btnRequest' type="button" className="btn btn-outline-info btn-sm" onClick={
                            () => {
                                onXmlViewClick(true, obj.IDENTIFIER + '-' + rowIndex, obj.REQUEST_CONTENT)
                            }
                        }>Request</button>
                        <button id='btnResponse' type="button" className="btn btn-outline-info btn-sm" onClick={
                            () => {
                                onXmlViewClick(true, obj.IDENTIFIER + '-' + rowIndex, obj.RESPONSE_CONTENT)
                            }
                        }>Response</button>
                    </div>
                },
            },
        ]
    }

    const JHWorksSchema = {
        columns: [
            { label: 'STATUS', field: 'EWSTATUS', type: 'ReadOnly', css: 'col-1' },
            { label: 'ID', field: 'ID', type: 'ReadOnly', css: 'col-1' },
            { label: 'IDOC NUMBER', field: 'IDOCNUMBER', type: 'ReadOnly', css: 'col-1' },
            { label: 'IDOC TYPE', field: 'IDOCTYPE', type: 'ReadOnly', dataType: 'ReadOnly', css: 'col-1' },
            { label: 'CONTENT TYPE', field: 'CONTENT_TYPE', type: 'ReadOnly', dataType: 'ReadOnly', css: 'col-1' },
            { label: 'ERROR CODE', field: 'ERRORCODE', type: 'ReadOnly', dataType: 'ReadOnly', css: 'col-1' },
            { label: 'ERROR TXT', field: 'ERRORTXT', type: 'ReadOnly', dataType: 'ReadOnly', css: 'col-1' },
            { label: 'DATE/TIME', field: 'DATE_CREATION', type: 'ReadOnly', dataType: 'DateTime', css: 'col-3' },
        ],
        rules: [
            { field: 'EWSTATUS', value: '-2', cssStyle: 'bg-red' }, // Heighlight Row in JH GREEN Color
            // { field: 'TIMER RUNNING', value: 'NO', cssStyle: 'bg-red text-white' },// Heighlight Row in Red Color
        ]
    }


    //this one works as data pool
    useEffect(() => {
        if (lastApiDataCount.current <= 0) {
            setClientSession({ ...session, events: session.addEvent(system === 'JHWorks' ? 'JHWorksQueueMessages' : 'MiiQueueMessages') })
            socket.emit('updateDTMSession', session)
        }

        const getData = (data) => {
            if (data) {
                data = data.data
                if (parseInt(data.length.toString()) > parseInt(lastApiDataCount.current.toString())) {
                    lastApiDataCount.current = data.length
                    setApiData(data)
                    console.log(`data received from api: ${data.length}`)

                    //Loading drop downs for IDOCTYPE or DOC_TYPE
                    let lstDocType = []
                    getJsonObjsArrayByKey(data, system === 'JHWorks' ? 'IDOCTYPE' : 'DOC_TYPE').forEach(item => {
                        lstDocType.push({ label: item, value: item })
                    })
                    lstDocType.sort(sortArrayObjByKey('value'))
                    setDocTypeList(lstDocType)

                    //Loading drop downs for CONTENT TYPE - JHWORKS
                    if (system === 'JHWorks') {
                        let lstContentType = []
                        getJsonObjsArrayByKey(data, 'CONTENT_TYPE').forEach(item => {
                            lstContentType.push({ label: item, value: item })
                        })
                        lstContentType.sort(sortArrayObjByKey('value'))
                        setContentTypeList(lstContentType)
                    }

                    let lstStatus = []
                    //Loading drop downs for EWSTATUS or STATUS
                    getJsonObjsArrayByKey(data, system === 'JHWorks' ? 'EWSTATUS' : 'STATUS').forEach(item => {
                        lstStatus.push({ label: item, value: item })
                    })
                    lstStatus.sort(sortArrayObjByKey('value'))
                    setStatusList(lstStatus)
                }
            }
        }

        if (system === 'MII') {
            socket.on('MiiQueueMessages', getData);
        }
        else if (system === 'JHWorks') {
            socket.on('JHWorksQueueMessages', getData)
        }

        // CLEAN UP THE EFFECT
        return () => {
            if (system === 'MII') {
                socket.off('MiiQueueMessages', getData());
            }
            else if (system === 'JHWorks') {
                socket.off('JHWorksQueueMessages', getData());
            }
            session.removeAllEvents()
        }
    }, [socket,]);


    //this one works to filter out latest data and update
    useEffect(() => {
        console.log('useEffect filtering data')

        if (apiData) {
            if (apiData.length > 0) {
                //allocating  selections
                let t = DocTypeMapping[system][id]

                //holding filtered data
                let tempData = apiData
                let tempList = []


                //MII Filters
                if (system === 'MII') {
                    session.docType = session.docType.concat(t)
                    session.contentType = []

                    if (session?.docType.length > 0) {
                        session?.docType?.forEach(item => {
                            tempList = tempList.concat(filterArrayObjByKey('DOC_TYPE', item.value, tempData))
                        })
                        tempData = tempList
                        tempList = []
                    }

                    if (session?.status.length > 0) {
                        session.status.forEach(item => {
                            tempList = tempList.concat(filterArrayObjByKey('STATUS', item.value, tempData))
                        })
                        tempData = tempList
                        tempList = []
                    }

                    if (session?.identifier !== null && session?.identifier !== undefined) {
                        tempList = tempList.concat(filterArrayObjByKey('IDENTIFIER', session.identifier, tempData, true))
                        tempData = tempList
                        tempList = []
                    }


                    if (session?.others !== null && session?.others !== undefined) {
                        tempList = tempList.concat(tempList.concat(filterArrayObjByKey('MESSAGE', session.others, tempData, true)))
                        tempData = tempList
                        tempList = []
                    }

                }

                //JHWorks Filters
                if (system === 'JHWorks') {
                    session.contentType = session.contentType.concat(t)

                    if (session?.docType.length > 0) {
                        session?.docType?.forEach(item => {
                            tempList = tempList.concat(filterArrayObjByKey('IDOCTYPE', item.value, tempData))
                        })
                        tempData = tempList
                        tempList = []
                    }

                    if (session?.contentType.length > 0) {
                        session?.contentType?.forEach(item => {
                            tempList = tempList.concat(filterArrayObjByKey('CONTENT_TYPE', item.value, tempData))
                        })
                        tempData = tempList
                        tempList = []
                    }

                    if (session?.status.length > 0) {
                        session?.status?.forEach(item => {
                            tempList = tempList.concat(filterArrayObjByKey('EWSTATUS', item.value, tempData))
                        })
                        tempData = tempList
                        tempList = []
                    }

                    if (session?.identifier !== null && session?.identifier !== undefined) {
                        tempList = tempList.concat(filterArrayObjByKey('ID', session.identifier, tempData, true))
                        tempData = tempList
                        tempList = []
                    }
                }

                //filter for Date Ranges on DATE_CREATION or RECEIVED_DATE_TIME
                let startDate = setDate(session?.startDate, 0, true)
                let endDate = setDate(session?.endDate, 1, true)
                let dateKey = system === 'JHWorks' ? 'DATE_CREATION' : 'RECEIVED_DATE_TIME'

                tempData = tempData.filter(row => {
                    let date = setDate(row[dateKey], 0, true)
                    if (date >= startDate && date <= endDate) {
                        return row
                    }
                })

                if (tempData?.length > 0) {
                    //sorting by date desc
                    sortArrayObjByDate(tempData, system === 'JHWorks' ? 'DATE_CREATION' : 'RECEIVED_DATE_TIME', false)

                    //Update react state to display available results
                    if (tempData.length !== filteredData.length) {
                        setFilteredData(tempData)
                        console.log(`filter data updated: ${tempData.length}`)
                    }
                }
                else {
                    //setting state to empty array when there are no results
                    setFilteredData([])
                }
            }
        }

    }, [apiData, session, setClientSession]);

    //on dates changed
    const dateChanged = (contId, date) => {
        if (contId === 'startDate') {
            setClientSession({ ...session, startDate: date, filterName: 'custom' })
        }
        if (contId === 'endDate') {
            setClientSession({ ...session, endDate: date, filterName: 'custom' })
        }
    }

    //on selection changed
    const ddlValueChange = (contId, selection) => {
        console.log('dropdown value change')
        let spreaded = [...DocTypeMapping[system][id], ...selection];
        spreaded = [...new Set(spreaded)]

        if (contId === 'ddlDocType') {
            setClientSession({ ...session, docType: spreaded })
        }
        else if (contId === 'ddlStatus') {
            setClientSession({ ...session, status: selection })
        }
        else if (contId === 'ddlContentType') {
            setClientSession({ ...session, contentType: selection })
        }
    }

    //socket events start
    const updateFilters = () => {
        //Notify server about the changes
        socket.emit('updateDTMSession', session)
    }
    const resetClientSession = () => {
        socket.emit('updateDTMSession', session)
        setClientSession({
            ...session,
            startDate: setDate(Date.now(), 0, false),
            endDate: setDate(Date.now(), 0, false),
            filterName: 'today',
            status: [],
            docType: [],
            // identifier: '',
            // others: '',
        })
    }
    //socket events end

    return (
        <div className='container-fluid'>
            <Header title={`DATA TRANSFER DETAILS (${system === 'JHWorks' ? 'JHWorks' : 'MII'})`} />
            <GlobalFilters />
            <PopupWindow config={popupModal} />



            {/* <GridView heading={`Messages for ${system === 'JHWorks' ? 'JHWorks' : 'MII'} Work Order SAP`} system={system} data={filteredData} /> */}

            <div className="card mt-1">
                <div className="card-header">
                    <h3>{`Messages for ${system === 'JHWorks' ? 'JHWorks' : 'MII'} Work Order SAP`}</h3>
                    <DataIndicator state={filteredData.length > 0} />
                </div>
                <div className="card-body " >
                    <div id="filter-container" className='mt-1 '>
                        <div className="row">
                            <div className="col  m-1">
                                <label >Start Date:</label>
                                <DatePicker className='filter-control' selected={session?.startDate} onSelect={(date) => dateChanged('startDate', date)} />
                            </div>
                            <div className="col  m-1">
                                <label > End Date:</label>
                                <DatePicker className='filter-control' selected={session?.endDate} onSelect={(date) => dateChanged('endDate', date)} />
                            </div>

                            <div className="col  m-1">
                                <Dropdown id='ddlStatus' label={system === 'JHWorks' ? 'EWStatus' : 'Status:'}
                                    list={statusList} onValueChange={ddlValueChange} style='filter-control'
                                    selectedValue={session.status} enableSelectAll={false} closeonChange={true} />
                            </div>
                            <div className="col  m-1">
                                <Dropdown id='ddlDocType' label={system === 'JHWorks' ? 'IDOC Type' : 'Document Type:'}
                                    list={docTypeList} onValueChange={ddlValueChange} style='filter-control'
                                    selectedValue={session.docType} enableSelectAll={true} closeonChange={true} />
                            </div>
                            <div className="col  m-1">
                                <label >{system === 'JHWorks' ? 'IDOC Number' : 'Identifier:'}</label>
                                <input id={system === 'JHWorks' ? 'IDOCNUMBER' : 'IDENTIFIER:'}
                                    type='text' className='filter-control' value={session.identifier === null ? '' : session.identifier}
                                    onChange={(e) => setClientSession({ ...session, identifier: e.target.value })} />
                            </div>
                            <div className="col  m-1">
                                {system === 'MII' ?
                                    <div>    <label > {system === 'JHWorks' ? '' : 'Message:'}</label>
                                        <input id={system === 'JHWorks' ? '' : 'MESSAGE:'}
                                            type='text' className='filter-control' value={session.others === null ? '' : session.others}
                                            onChange={(e) => setClientSession({ ...session, others: e.target.value })} />
                                    </div> :
                                    <Dropdown id='ddlContentType' label='CONTENT Type'
                                        list={contentTypeList} onValueChange={ddlValueChange} style='filter-control'
                                        selectedValue={session.contentType} enableSelectAll={true} closeonChange={true} />
                                }
                            </div>


                            <div className="col d-flex justify-content-start align-items-end">
                                <div className="gap-2 d-md-flex ">
                                    <button type="button" onClick={() => {
                                        updateFilters()
                                    }} className="btn btn-info btn-sm mb-1">Go</button>
                                    <button type="button" onClick={() => {
                                        resetClientSession()
                                    }} className="btn btn-warning btn-sm mb-1">Reset
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className='mt-2'>
                        <GridView
                            schema={system === 'JHWorks' ? JHWorksSchema : MiiSchema} data={filteredData} />
                    </div>
                </div>
            </div>



        </div >
    )
}

export default DataTransferDetails