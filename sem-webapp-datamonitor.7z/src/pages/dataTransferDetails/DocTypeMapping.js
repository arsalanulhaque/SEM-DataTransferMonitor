export const DocTypeMapping = {
    MII: {
        MiiGeneral: [],
        MiiWorkOrder: [
            { label: 'WORK_ORDER_CLEAN_ISCALA', value: 'WORK_ORDER_CLEAN_ISCALA' },
            { label: 'WORK_ORDER_ROUTER', value: 'WORK_ORDER_ROUTER' }
        ],
        MiiWorkOrdersConfirmation: [
            { label: 'WORK_ORDER_CONFIRMATION_JHWORKS', value: 'WORK_ORDER_CONFIRMATION_JHWORKS' },
            { label: 'WORK_ORDER_STARTED_JHWORKS', value: 'WORK_ORDER_STARTED_JHWORKS' }],
        MiiSerialNumbers: [
            { label: 'SERIAL_NUMBER_ADAPTER', value: 'SERIAL_NUMBER_ADAPTER' }
        ],
        MiiReceivedSerialNumbers: [
            { label: 'RECEIVED_SERIAL_NUMBER_JHMW', value: 'RECEIVED_SERIAL_NUMBER_JHMW' }
        ]
    },
    JHWorks: { //Filters based on Content Type
        JHWorksGeneral: [],
        JHWorksWorkOrder: [
            { label: 10, value: 10 }
        ],
        JHWorksConfirmWorkOrder: [
            { label: 11, value: 11 }
        ]
    }
}