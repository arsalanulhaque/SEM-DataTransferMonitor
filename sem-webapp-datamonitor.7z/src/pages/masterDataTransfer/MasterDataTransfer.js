import "../../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import Header from '../../components/Header';
import GlobalFilters from '../../components/GlobalFilters'
import TimersKPI from './TimersKPI/Index'
import NewProductsKPI from './NewProductsKPI/Index'
import UntransferredSerialNumbersKPI from './UntransferredSerialNumbersKPI/Index'

const MasterDataTransfer = () => {
    return (
        <div className="container-fluid">
            <Header title="DATA TRANSFER DETAILS" />
            <GlobalFilters />

            <div className="row mt-1 ">
                <div className="col">

                    {/* Untransferred Serial Number */}
                    <UntransferredSerialNumbersKPI />
                    {/* Timers KPI */}
                    <TimersKPI />
                </div>

                {/* NewProductsKPI */}
                <div className="col" >
                    <NewProductsKPI />
                </div>
            </div>
        </div>
    )
}

export default MasterDataTransfer;