import React, { useState, useEffect, useContext, useRef } from 'react';
import "../../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import Header from '../../components/Header';
import GridView from '../../controls/GridView/GridView';
import GlobalFilters from '../../components/GlobalFilters'
import { SocketContext } from '../../context/Socket';
import { SessionContext } from '../../context/Session';
import DataIndicator from "../../components/DataIndicator"
import PopupWindow from '../dataTransferDetails/page_components/PopupWindow'
import { sortArrayObjByDate } from '../../helper'


const MasterDataTransfer = () => {
    const socket = useContext(SocketContext)
    const { session, setClientSession } = useContext(SessionContext)
    const [dataNewProducts, setDataNewProducts] = useState([])
    const [dataUntransferredSNo, setDataUntransferredSNo] = useState([])
    const [dataTimers, setTimers] = useState([])
    const [popupModal, setPopupModal] = useState({ 'isVisible': false, 'content': null })

    const masterDataSchema = {
        columns: [
            { label: 'Part ID', field: 'PART_ID', type: 'ReadOnly', css: 'col-1' },
            { label: 'Part Number', field: 'PART_NUMBER', type: 'ReadOnly', css: 'col-1' },
            { label: 'Part Description', field: 'PART_DESC', type: 'ReadOnly', css: 'col-2' },
            { label: 'Flag', field: 'PRODUCT_FLAG', type: 'ReadOnly', css: 'col-1' },
            { label: 'Created On', field: 'CREATED_DATE', type: 'ReadOnly', dataType: 'DateTime', css: 'col-2' },
            { label: 'Modified On', field: 'MODIFIED_DATE', type: 'ReadOnly', dataType: 'DateTime', css: 'col-2' }
        ]
    }

    const serialSchema = {
        columns: [
            { label: 'Start Date', field: 'WORKORDER_START_DATE', type: 'ReadOnly', dataType: 'DateTime', css: 'col-2' },
            { label: 'Time Due', field: 'TIME_DIFF', type: 'ReadOnly', css: 'col-1' },
            { label: 'Work Order', field: 'WORKORDER_NO', type: 'ReadOnly', css: 'col-1' },
            { label: 'Part Number', field: 'PART_NUMBER', type: 'ReadOnly', css: 'col-1' },
            {
                label: 'Trigger SN Transfer', type: 'Action', css: 'col-1',
                template: (rowIndex, obj) => {
                    return <button type="button" className="btn btn-outline-info btn-sm" onClick={(e) => {
                        e.preventDefault()
                        console.log('Index: ', rowIndex, 'obj: ', obj)
                        //Notify server about the changes
                        session.inputParams = { 'WorkOrder': obj.WORKORDER_NO, 'PartNumber': obj.PART_NUMBER }
                        socket.emit('TriggerUntransferredSNo', session)
                    }}> Transfer</button >
                }
            }
        ]
    }

    const timersSchema = {
        columns: [
            { label: 'Identity', field: 'A_IDENTITY', type: 'ReadOnly', css: 'col-3', trunacteSize: '100' },
            { label: 'Status', field: 'TIMER RUNNING', type: 'ReadOnly', css: 'col-1' },
            { label: 'Started On', field: 'START_HISTORY', type: 'ReadOnly', dataType: 'DateTime', css: 'col-2' },
            { label: 'Completed On', field: 'CHANGE_STAMP', type: 'ReadOnly', dataType: 'DateTime', css: 'col-2' },
        ],
        rules: [
            { field: 'TIMER RUNNING', value: 'YES', cssStyle: 'jh-green text-white' }, // Heighlight Row in JH GREEN Color
            { field: 'TIMER RUNNING', value: 'NO', cssStyle: 'bg-danger text-white' },// Heighlight Row in Red Color
        ]
    }
        ;
    //Popup Window Handler
    const onXmlViewClick = (isVisible, content) => {
        if (isVisible)
            setPopupModal({
                'isVisible': isVisible, 'title': 'Response', 'content': content, onXmlViewClick: onXmlViewClick
            })
        else {
            setPopupModal({ 'isVisible': isVisible, 'title': null, 'content': null, onXmlViewClick: null })
        }
    }


    useEffect(() => {
        if (dataNewProducts?.length === 0) {
            setClientSession({ ...session, events: session.addEvent('NewProducts', false) })
            socket.emit('updateDTMSession', session)
        }
        if (dataUntransferredSNo?.length === 0) {
            //session.addEvent('UntransferredSNo', false)
            setClientSession({ ...session, events: session.addEvent('UntransferredSNo', false) })
            socket.emit('updateDTMSession', session)
        }

        if (dataTimers?.length === 0) {
            //session.addEvent('UntransferredSNo', false)
            setClientSession({ ...session, events: session.addEvent('Timers', false) })
            socket.emit('updateDTMSession', session)
        }

        const getUntransferredSNo = (data) => {
            if (data) {
                data = data.data
                if (data.length > 0) {
                    setDataUntransferredSNo(data);
                    console.log(`Data received from Untransferred Serial No API: ${data.length}.`)
                }
                else {
                    if (dataUntransferredSNo.length > 0) {
                        setDataUntransferredSNo([]);
                        console.log('No data recieved from Untransferred Serial No. API!')
                    }
                }
            }
        }

        const getNewProducts = (data) => {
            if (data) {
                data = data.data
                if (data.length > 0) {
                    setDataNewProducts(data);
                    console.log(`Data received from New Products API:${data.length}.`)
                }
                else {
                    setDataNewProducts([]);
                    console.log('No data recieved from New Products API!')
                }
            }
        }

        const getTimers = (data) => {
            if (data) {
                data = data.data
                if (data.length > 0) {
                    sortArrayObjByDate(data, 'CHANGE_STAMP', false)
                    setTimers(data);
                    console.log(`Data received from Timers API:${data.length}.`)
                }
                else {
                    setTimers([]);
                    console.log('No data recieved from Timers API!')
                }
            }
        }
        const ResponseToTriggerUntransferredSNo = (data) => {
            if (data) {
                onXmlViewClick(true, data.data)
            }
        }

        socket.on('ResponseToTriggerUntransferredSNo', ResponseToTriggerUntransferredSNo);
        socket.on('UntransferredSNo', getUntransferredSNo);
        socket.on('NewProducts', getNewProducts);
        socket.on('Timers', getTimers);

        // CLEAN UP THE EFFECT
        return () => {
            socket.off('ResponseToTriggerUntransferredSNo', ResponseToTriggerUntransferredSNo());
            socket.off('UntransferredSNo', getUntransferredSNo());
            socket.off('NewProducts', getNewProducts());
            socket.off('Timers', getNewProducts());
            session.removeAllEvents()
        }
    }, [socket, dataUntransferredSNo, dataNewProducts, dataTimers]);


    return (
        <div className="container-fluid">
            <Header title="DATA TRANSFER DETAILS" />
            <GlobalFilters />
            <PopupWindow config={popupModal} />

            <div className="row mt-1 ">
                <div className="col">

                    <div className="card mb-2">
                        <div className="card-header">
                            <h3>Untransferred Serial Numbers</h3>
                            <DataIndicator state={dataUntransferredSNo.length > 0} />
                        </div>
                        <div className="card-body " >
                            <GridView schema={serialSchema} data={dataUntransferredSNo} />
                        </div>
                    </div>

                    <div className="card ">
                        <div className="card-header">
                            <h3>Timers</h3>
                            <DataIndicator state={dataTimers.length > 0} />
                        </div>
                        <div className="card-body " >
                            <GridView schema={timersSchema} data={dataTimers} />
                        </div>
                    </div>

                </div>

                <div className="col" >
                    <div className="card">
                        <div className="card-header">
                            <h3>Recipe - Master Preparation</h3>
                            <DataIndicator state={dataNewProducts.length > 0} />
                        </div>
                        <div className="card-body " >
                            <GridView schema={masterDataSchema} data={dataNewProducts} isSerialCol={false} />
                        </div>
                    </div>
                </div>
            </div>



        </div>
    )
}

export default MasterDataTransfer;