import { useEffect, useState, useContext, } from "react";
import { SocketContext } from '../../../../context/Socket';
import { SessionContext } from "../../../../context/Session"
import { sortArrayObjByDate } from '../../../../helper'

export const useData = () => {
    const { session, setClientSession } = useContext(SessionContext)
    const socket = useContext(SocketContext)
    const [objData, setData] = useState([]);
    const timersSchema = {
        columns: [
            { label: 'Identity', field: 'A_IDENTITY', type: 'ReadOnly', css: 'col-3', trunacteSize: '100' },
            { label: 'Status', field: 'TIMER RUNNING', type: 'ReadOnly', css: 'col-1' },
            { label: 'Started On', field: 'START_HISTORY', type: 'ReadOnly', dataType: 'DateTime', css: 'col-2' },
            { label: 'Completed On', field: 'CHANGE_STAMP', type: 'ReadOnly', dataType: 'DateTime', css: 'col-2' },
        ],
        rules: [
            { field: 'TIMER RUNNING', value: 'YES', cssStyle: 'jh-green text-white' }, // Heighlight Row in JH GREEN Color
            { field: 'TIMER RUNNING', value: 'NO', cssStyle: 'bg-danger text-white' },// Heighlight Row in Red Color
        ]
    }

    useEffect(() => {
        let event = session.events.find(e => e === 'Timers')
        if (objData?.length === 0 && !event) {
            setClientSession({ ...session, events: session.addEvent('Timers', false) })
            socket.emit('updateDTMSession', session)
        }

        const getData = (resp) => {
            if (resp) {
                let data = resp?.data
                if (data?.length > 0) {
                    sortArrayObjByDate(data, 'CHANGE_STAMP', false)
                    setData(data)
                    console.log(`Data received from Timers API:${data.length}.`)
                }
                else {
                    setData([]);
                    console.log('No data recieved from Timers API!')
                }
            }
        }

        socket.on('Timers', getData);

        // CLEAN UP THE EFFECT
        return () => {
            socket.off('Timers', getData());
        }
    }, [socket, objData,])

    return { objData, timersSchema }
}