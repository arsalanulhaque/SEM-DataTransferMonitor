import { useData } from "./hooks/useData";
import GridView from '../../../controls/GridView/GridView';
import DataIndicator from "../../../components/DataIndicator"

const Index = () => {
    const { objData, timersSchema } = useData();

    return (
        <div className="card ">
            <div className="card-header">
                <h3>Timers</h3>
                <DataIndicator state={objData.length > 0} />
            </div>
            <div className="card-body " >
                <GridView schema={timersSchema} data={objData} />
            </div>
        </div>
    )
}

export default Index;