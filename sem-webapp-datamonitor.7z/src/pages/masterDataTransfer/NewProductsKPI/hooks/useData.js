import { useEffect, useState, useContext, } from "react";
import { SocketContext } from '../../../../context/Socket';
import { SessionContext } from "../../../../context/Session"

export const useData = () => {
    const socket = useContext(SocketContext)
    const { session, setClientSession } = useContext(SessionContext)
    const [objData, setData] = useState([]);
    const masterDataSchema = {
        columns: [
            { label: 'Part ID', field: 'PART_ID', type: 'ReadOnly', css: 'col-1' },
            { label: 'Part Number', field: 'PART_NUMBER', type: 'ReadOnly', css: 'col-1' },
            { label: 'Part Description', field: 'PART_DESC', type: 'ReadOnly', css: 'col-2' },
            { label: 'Flag', field: 'PRODUCT_FLAG', type: 'ReadOnly', css: 'col-1' },
            { label: 'Created On', field: 'CREATED_DATE', type: 'ReadOnly', dataType: 'DateTime', css: 'col-2' },
            { label: 'Modified On', field: 'MODIFIED_DATE', type: 'ReadOnly', dataType: 'DateTime', css: 'col-2' }
        ]
    }

    useEffect(() => {
        let event = session.events.find(e => e === 'NewProducts')
        if (objData?.length === 0 && !event) {
            setClientSession({ ...session, events: session.addEvent('NewProducts', false) })
            socket.emit('updateDTMSession', session)
        }

        const getData = (resp) => {
            if (resp) {
                let data = resp?.data
                if (data.length > 0) {
                    setData(data);
                    console.log(`Data received from Master Recipe API:${data.length}.`)
                }
                else {
                    setData([]);
                    console.log('No data recieved from  Master Recipe API!')
                }
            }
        }

        socket.on('NewProducts', getData);

        // CLEAN UP THE EFFECT
        return () => {
            socket.off('NewProducts', getData());

        }
    }, [socket, objData,])

    return { objData, masterDataSchema }
}