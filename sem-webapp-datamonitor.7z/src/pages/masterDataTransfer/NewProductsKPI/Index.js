import { useData } from "./hooks/useData";
import GridView from '../../../controls/GridView/GridView';
import DataIndicator from "../../../components/DataIndicator"

const Index = () => {
    const { objData, masterDataSchema } = useData();

    return (
        <div className="card">
            <div className="card-header">
                <h3>Recipe - Master Preparation</h3>
                <DataIndicator state={objData.length > 0} />
            </div>
            <div className="card-body " >
                <GridView schema={masterDataSchema} data={objData} isSerialCol={true} />
            </div>
        </div >
    )
}

export default Index;