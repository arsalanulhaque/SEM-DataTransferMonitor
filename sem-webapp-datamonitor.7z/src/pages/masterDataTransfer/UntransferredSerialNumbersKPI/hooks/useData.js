import { useEffect, useState, useContext, } from "react";
import { SocketContext } from '../../../../context/Socket';
import { SessionContext } from "../../../../context/Session"

export const useData = () => {
    const socket = useContext(SocketContext)
    const { session, setClientSession } = useContext(SessionContext)
    const [objData, setData] = useState([]);
    const [popupModal, setPopupModal] = useState({ 'isVisible': false, 'content': null })
    const serialSchema = {
        columns: [
            { label: 'Start Date', field: 'WORKORDER_START_DATE', type: 'ReadOnly', dataType: 'DateTime', css: 'col-2' },
            { label: 'Time Due', field: 'TIME_DIFF', type: 'ReadOnly', css: 'col-1' },
            { label: 'Work Order', field: 'WORKORDER_NO', type: 'ReadOnly', css: 'col-1' },
            { label: 'Part Number', field: 'PART_NUMBER', type: 'ReadOnly', css: 'col-1' },
            {
                label: 'Trigger SN Transfer', type: 'Action', css: 'col-1',
                template: (rowIndex, obj) => {
                    return <button type="button" className="btn btn-outline-info btn-sm" onClick={(e) => {
                        e.preventDefault()
                        console.log('Index: ', rowIndex, 'obj: ', obj)
                        //Notify server about the changes
                        session.inputParams = { 'WorkOrder': obj.WORKORDER_NO, 'PartNumber': obj.PART_NUMBER }
                        socket.emit('TriggerUntransferredSNo', session)
                    }}> Transfer</button >
                }
            }
        ]
    }

    //Popup Window Handler
    const onXmlViewClick = (isVisible, content) => {
        if (isVisible)
            setPopupModal({
                'isVisible': isVisible, 'title': 'Response', 'content': content, onXmlViewClick: onXmlViewClick
            })
        else {
            setPopupModal({ 'isVisible': isVisible, 'title': null, 'content': null, onXmlViewClick: null })
        }
    }

    useEffect(() => {
        let event = session.events.find(e => e === 'UntransferredSNo')

        if (objData?.length === 0 && !event) {
            setClientSession({ ...session, events: session.addEvent('UntransferredSNo', false) })
            socket.emit('updateDTMSession', session)
        }

        const getData = (resp) => {
            if (resp) {
                let data = resp?.data
                if (data.length > 0) {
                    setData(data);
                    console.log(`Data received from Untransferred Serials API:${data.length}.`)
                }
                else {
                    setData([]);
                    console.log('No data recieved from Untransferred Serials API!')
                }
            }
        }

        const ResponseToTriggerUntransferredSNo = (data) => {
            if (data) {
                onXmlViewClick(true, data.data)
            }
        }

        socket.on('ResponseToTriggerUntransferredSNo', ResponseToTriggerUntransferredSNo);
        socket.on('UntransferredSNo', getData);

        // CLEAN UP THE EFFECT
        return () => {
            socket.off('UntransferredSNo', getData());
        }
    }, [socket, objData,])

    return { objData, serialSchema, popupModal }
}