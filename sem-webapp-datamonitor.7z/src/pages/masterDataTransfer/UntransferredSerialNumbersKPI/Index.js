import { useData } from "./hooks/useData";
import GridView from '../../../controls/GridView/GridView';
import DataIndicator from "../../../components/DataIndicator"
import PopupWindow from '../../dataTransferDetails/page_components/PopupWindow'

const Index = () => {
    const { objData, serialSchema, popupModal } = useData();

    return (
        <>
            <PopupWindow config={popupModal} />
            <div className="card mb-2">
                <div className="card-header">
                    <h3>Untransferred Serial Numbers</h3>
                    <DataIndicator state={objData?.length > 0} />
                </div>
                <div className="card-body " >
                    <GridView schema={serialSchema} data={objData} />
                </div>
            </div>
        </>
    )
}

export default Index;